<?php
 $dbhost = "localhost";  
 $dbuser = "root";
 $dbpass = "";
 $db = "test";
 $conn = new mysqli($dbhost,$dbuser, $dbpass,$db) or die();
 echo "connected successfully";
 $sid=$_POST['uname'];
 $sname=$_POST['eid'];
 $sdept=$_POST['phno'];
 $passw=$_POST['pass'];
 $gend=$_POST['gender'];

 $res = mysqli_query($conn,"insert into firsttable values('$sid','$sname','$sdept','$passw','$gend')");
$res1=mysqli_query($conn,"select * from firsttable");
echo "<script language='javascript' type='text/javascript'>";
echo "alert('You have logged in successfully');";
echo "</script>";

$URL="homepage.html";
echo "<script>location.href='$URL'</script>";

 $conn -> close();
    
?>