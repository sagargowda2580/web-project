-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 24, 2021 at 09:54 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `availablitytable`
--

CREATE TABLE `availablitytable` (
  `roomid` varchar(7) NOT NULL,
  `checkin` date NOT NULL,
  `checkout` date NOT NULL,
  `adults` int(2) NOT NULL,
  `children` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `availablitytable`
--

INSERT INTO `availablitytable` (`roomid`, `checkin`, `checkout`, `adults`, `children`) VALUES
('room1', '2020-12-15', '2020-12-17', 0, 0),
('room1', '2020-12-15', '2020-12-17', 0, 0),
('room1', '2020-12-15', '2020-12-16', 0, 0),
('room1', '2020-12-15', '2020-12-16', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-17', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-17', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-15', '2020-12-17', 0, 0),
('room1', '2020-12-16', '2020-12-18', 0, 0),
('room1', '2020-12-18', '2020-12-22', 0, 0),
('room1', '2020-12-17', '2020-12-20', 0, 0),
('room1', '2020-12-25', '2020-12-31', 0, 0),
('room1', '2020-12-28', '2020-12-30', 0, 0),
('room1', '2020-12-28', '2020-12-30', 0, 0),
('room1', '2020-12-31', '2021-01-02', 0, 0),
('room1', '2021-01-01', '2021-01-05', 0, 0),
('room1', '2021-01-10', '2021-01-09', 0, 0),
('room1', '2021-01-27', '2021-01-29', 0, 0),
('room1', '2021-01-27', '2021-01-29', 0, 0),
('room1', '2021-01-28', '2021-01-30', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `feedsback`
--

CREATE TABLE `feedsback` (
  `name` varchar(15) NOT NULL,
  `email` varchar(20) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `feeds` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedsback`
--

INSERT INTO `feedsback` (`name`, `email`, `phonenumber`, `feeds`) VALUES
('sagar', 'sagar25@gmail.com', 9882563, 'its  a very good app nigga enjoy'),
('sagar g', 'sagarg@gmail.com', 456782341, 'it was fablalous');

-- --------------------------------------------------------

--
-- Table structure for table `firsttable`
--

CREATE TABLE `firsttable` (
  `username` varchar(10) NOT NULL,
  `email` varchar(25) NOT NULL,
  `phonenumber` int(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `gender` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `firsttable`
--

INSERT INTO `firsttable` (`username`, `email`, `phonenumber`, `password`, `gender`) VALUES
('', '', 0, '', ''),
('', '', 0, '', ''),
('', '', 0, '', ''),
('', '', 0, '', ''),
('sagar', 'sagar25@gmail.com', 12345678, '12345678', 'male'),
('sagar2555', 'sagar2534@gmail.com', 12349898, '1234sagar', 'male'),
('sagar2555', 'sagar2534@gmail.com', 12349898, '123456789', 'male'),
('', '', 0, '', ''),
('xyz', 'xyz@gmail.com', 988120900, 'sagarbest', 'femal'),
('', '', 0, '', ''),
('', '', 0, '', ''),
('chetan', 'chetan67@hotmail.com', 2147483647, 'ghjkij', 'male'),
('dumbo', 'dumbo@email.com', 2147483647, 'dumbo', 'femal'),
('sahana', 'sahana@yahoo.com', 910000091, 'lizaed', 'femal'),
('', '', 0, '', ''),
('rakshith', 'rakshith@gmail.com', 2147483647, 'rakshii', 'femal'),
('', '', 0, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` varchar(5) NOT NULL,
  `sname` varchar(10) NOT NULL,
  `sdept` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
