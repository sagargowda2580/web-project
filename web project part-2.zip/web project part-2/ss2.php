<?php
 $dbhost = "localhost";  
 $dbuser = "root";
 $dbpass = "";
 $db = "test";
 $conn = new mysqli($dbhost,$dbuser, $dbpass,$db) or die();
 echo "connected successfully";
 $sid=$_POST['uname'];
 $sdept=$_POST['phno'];
 $passw=$_POST['pass'];
$res1=mysqli_query($conn,"select * from firsttable");
$res=mysqli_query($conn,"select *from firsttable where username= '$sid' and password='$passw'") or die();
$row=mysqli_fetch_array($res);
if($row['username']==$sid && $row['password']==$passw && $row['phonenumber']==$sdept)
{
echo "<script language='javascript' type='text/javascript'>";
echo "alert('You are taken to home page');";
echo "</script>";

$URL="homepage.html";
echo "<script>location.href='$URL'</script>";

}
else
{
echo "<script language='javascript' type='text/javascript'>";
echo "alert('You have entered wrong details');";
echo "</script>";

$URL="newuserloginpage.html";
echo "<script>location.href='$URL'</script>";

}

 $conn -> close();
    
?>
 
