<?php
 $dbhost = "localhost";  
 $dbuser = "root";
 $dbpass = "";
 $db = "test";
 $conn = new mysqli($dbhost,$dbuser, $dbpass,$db) or die();
 echo "connected successfully";
 $sid=$_POST['a'];
 $sname=$_POST['b'];
 $sdept=$_POST['c'];
 $passw=$_POST['d'];


 $res = mysqli_query($conn,"insert into feedsback values('$sid','$sname','$sdept','$passw')");
$res1=mysqli_query($conn,"select * from feedback");
echo "<script language='javascript' type='text/javascript'>";
echo "alert('THANK YOU FOR VISITING');";
echo "</script>";

$URL="homepage.html";
echo "<script>location.href='$URL'</script>";

 $conn -> close();
    
?>