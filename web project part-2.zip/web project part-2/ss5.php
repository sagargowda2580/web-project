<?php
 $dbhost = "localhost";  
 $dbuser = "root";
 $dbpass = "";
 $db = "test";
 $conn = new mysqli($dbhost,$dbuser, $dbpass,$db) or die();
 
 $sid=$_POST['no1'];
 $sname=$_POST['no2'];
$roomsid="room1";
$d1=$_POST['no3'];
$d2=$_POST['no4'];
 
session_start(); 
if (!IsSet($_SESSION["page1_number"]))
$_SESSION["page1_number"]= 1;
$page_num= $_SESSION["page1_number"];

if ($_SESSION["page1_number"]==1)
{

 $res = mysqli_query($conn,"insert into availablitytable values('$roomsid','$sid','$sname','$d1','$d2')");

echo "<script language='javascript' type='text/javascript'>";
echo "alert(' available');";
echo "</script>";
$URL="reserve2.html";
echo "<script>location.href='$URL'</script>";


}
else
{
echo "<script language='javascript' type='text/javascript'>";
echo "alert('not available');";
echo "</script>";
$URL="index22.html";
echo "<script>location.href='$URL'</script>";
session_destroy();
}


$_SESSION["page1_number"]++;


 $conn -> close();
    
?>