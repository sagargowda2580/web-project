<?php
 $dbhost = "localhost";  
 $dbuser = "root";
 $dbpass = "";
 $db = "test";
 $conn = new mysqli($dbhost,$dbuser, $dbpass,$db) or die();
 echo "connected successfully";
 $uname=$_GET['uname']
 $eid=$_GET['eid'];
 $phno=$_GET['phno'];
 $pass=$_GET['pass']
 $gender=$_GET['gender'];
 $res = mysqli_query($conn,"insert into project1 values('$uname','$eid','$phno','$pass','$gender')");
$res1=mysqli_query($conn,"select * from project1");
print "<center><table cellspacing=2 cellpadding=3 border=1>";
print "<tr><th>slno</th><th>uname</th><th>eid</th><th>phone</th>";
print "</tr>";
$i=1;
while($row = mysqli_fetch_array($res1))
{
print "<tr><td>$i</td><td>$row[0]</td><td>$row[1]</td>";
print "<td>$row[2]</td></tr>";
$i++;
}


   $conn -> close();
    
?>